const api = '/api';

function setMessage(text) {
  document.getElementById('message').textContent = text || '';
}

async function checkFeature() {
  const result = document.getElementById('result');
  result.className = 'result hidden';
  result.innerHTML = '';
  setMessage('');

  try {
    const body = {
      organizationCode: document.getElementById('organizationCode').value,
      featureKey: document.getElementById('featureKey').value
    };

    const response = await fetch(api + '/check-feature', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.message || 'Unable to check feature');

    result.className = `result ${data.isEnabled ? 'enabled' : 'disabled'}`;
    result.innerHTML = `
      <strong>${data.featureKey}</strong>
      <p>Organization: ${data.organization}</p>
      <h2>${data.isEnabled ? 'Enabled' : 'Disabled'}</h2>
    `;
  } catch (err) {
    setMessage(err.message);
  }
}
