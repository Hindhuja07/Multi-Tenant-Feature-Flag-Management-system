const api = '/api';
const tokenKey = 'org_admin_token';
const userKey = 'org_admin_user';

function setMessage(text) {
  document.getElementById('message').textContent = text || '';
}

function getToken() {
  return localStorage.getItem(tokenKey);
}

function getUser() {
  try { return JSON.parse(localStorage.getItem(userKey)); } catch { return null; }
}

async function request(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(api + path, { ...options, headers });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || 'Something went wrong');
  return data;
}

async function signup() {
  try {
    const body = {
      name: document.getElementById('signupName').value,
      email: document.getElementById('signupEmail').value,
      password: document.getElementById('signupPassword').value,
      organizationCode: document.getElementById('signupOrgCode').value
    };
    const data = await request('/admin/signup', { method: 'POST', body: JSON.stringify(body) });
    saveSession(data);
  } catch (err) {
    setMessage(err.message);
  }
}

async function login() {
  try {
    const body = {
      email: document.getElementById('loginEmail').value,
      password: document.getElementById('loginPassword').value
    };
    const data = await request('/admin/login', { method: 'POST', body: JSON.stringify(body) });
    saveSession(data);
  } catch (err) {
    setMessage(err.message);
  }
}

function saveSession(data) {
  localStorage.setItem(tokenKey, data.token);
  localStorage.setItem(userKey, JSON.stringify(data.user));
  showDashboard();
  loadFlags();
}

function showDashboard() {
  const user = getUser();
  document.getElementById('authBox').classList.add('hidden');
  document.getElementById('dashboard').classList.remove('hidden');
  document.getElementById('adminName').textContent = user ? user.name : 'Organization Admin';
  document.getElementById('orgName').textContent = user ? user.organizationName : '';
}

function logout() {
  localStorage.removeItem(tokenKey);
  localStorage.removeItem(userKey);
  location.reload();
}

async function createFlag() {
  try {
    const body = {
      featureKey: document.getElementById('featureKey').value,
      description: document.getElementById('description').value,
      isEnabled: document.getElementById('isEnabled').checked
    };
    await request('/flags', { method: 'POST', body: JSON.stringify(body) });
    document.getElementById('featureKey').value = '';
    document.getElementById('description').value = '';
    document.getElementById('isEnabled').checked = false;
    setMessage('Feature flag created');
    loadFlags();
  } catch (err) {
    setMessage(err.message);
  }
}

async function loadFlags() {
  try {
    const data = await request('/flags');
    const target = document.getElementById('flags');
    if (!data.flags.length) {
      target.innerHTML = '<p class="hint">No flags created yet.</p>';
      return;
    }
    target.innerHTML = data.flags.map(flag => `
      <div class="card">
        <strong>${flag.feature_key}</strong>
        <span class="badge ${flag.is_enabled ? 'on' : 'off'}">${flag.is_enabled ? 'Enabled' : 'Disabled'}</span>
        <p class="hint">${flag.description || 'No description'}</p>
        <div class="actions">
          <button onclick="toggleFlag(${flag.id}, ${flag.is_enabled ? 0 : 1}, '${escapeText(flag.description || '')}')">
            ${flag.is_enabled ? 'Disable' : 'Enable'}
          </button>
          <button class="danger" onclick="deleteFlag(${flag.id})">Delete</button>
        </div>
      </div>
    `).join('');
  } catch (err) {
    setMessage(err.message);
  }
}

function escapeText(value) {
  return value.replace(/'/g, '&#39;');
}

async function toggleFlag(id, enabled, description) {
  try {
    await request(`/flags/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ isEnabled: !!enabled, description })
    });
    loadFlags();
  } catch (err) {
    setMessage(err.message);
  }
}

async function deleteFlag(id) {
  if (!confirm('Delete this feature flag?')) return;
  try {
    await request(`/flags/${id}`, { method: 'DELETE' });
    loadFlags();
  } catch (err) {
    setMessage(err.message);
  }
}

if (getToken()) {
  showDashboard();
  loadFlags();
}
