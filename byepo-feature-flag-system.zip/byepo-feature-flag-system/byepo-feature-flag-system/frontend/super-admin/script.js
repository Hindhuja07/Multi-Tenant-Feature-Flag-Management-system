const api = '/api';
const tokenKey = 'super_admin_token';

function setMessage(text) {
  document.getElementById('message').textContent = text || '';
}

function getToken() {
  return localStorage.getItem(tokenKey);
}

async function request(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(api + path, { ...options, headers });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || 'Something went wrong');
  return data;
}

async function login() {
  try {
    setMessage('');
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const data = await request('/super-admin/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
    localStorage.setItem(tokenKey, data.token);
    showDashboard(data.user.email);
    loadOrganizations();
  } catch (err) {
    setMessage(err.message);
  }
}

function showDashboard(email) {
  document.getElementById('loginBox').classList.add('hidden');
  document.getElementById('dashboard').classList.remove('hidden');
  document.getElementById('whoami').textContent = `Logged in as ${email || 'Super Admin'}`;
}

function logout() {
  localStorage.removeItem(tokenKey);
  location.reload();
}

async function createOrganization() {
  try {
    const name = document.getElementById('orgName').value;
    await request('/organizations', {
      method: 'POST',
      body: JSON.stringify({ name })
    });
    document.getElementById('orgName').value = '';
    setMessage('Organization created successfully');
    loadOrganizations();
  } catch (err) {
    setMessage(err.message);
  }
}

async function loadOrganizations() {
  try {
    const data = await request('/organizations');
    const target = document.getElementById('organizations');
    if (!data.organizations.length) {
      target.innerHTML = '<p class="hint">No organizations created yet.</p>';
      return;
    }
    target.innerHTML = data.organizations.map(org => `
      <div class="card">
        <strong>${org.name}</strong><br />
        <span class="code">${org.code}</span>
        <p class="hint">Admins: ${org.admin_count} | Flags: ${org.flag_count}</p>
      </div>
    `).join('');
  } catch (err) {
    setMessage(err.message);
  }
}

if (getToken()) {
  showDashboard('Super Admin');
  loadOrganizations();
}
