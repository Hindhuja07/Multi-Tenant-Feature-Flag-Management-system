# Multi-Tenant Feature Flag Management System

A small SaaS-style feature flag management system built for the Byepo Technologies task-based assessment.

## What is included

- Node.js + Express backend
- SQLite persistent database
- Custom JWT authentication
- Super Admin frontend
- Organization Admin frontend
- End User frontend
- Role-scoped APIs
- Organization-scoped feature flags

## Folder structure

```text
byepo-feature-flag-system/
├── backend/
│   ├── db.js
│   ├── middleware.js
│   ├── routes.js
│   └── server.js
├── frontend/
│   ├── super-admin/
│   ├── admin/
│   └── user/
├── .env.example
├── package.json
└── README.md
```

## Setup

```bash
npm install
cp .env.example .env
npm start
```

Backend runs at:

```text
http://localhost:5000
```

Open the frontends in browser:

```text
http://localhost:5000/super-admin
http://localhost:5000/admin
http://localhost:5000/user
```

## Default Super Admin Login

```text
Email: superadmin@byepo.local
Password: Admin@123
```

You can change these values in `.env`.

## Basic flow

1. Login as Super Admin.
2. Create an organization.
3. Go to Admin frontend.
4. Signup an organization admin using the organization code shown in Super Admin page.
5. Login as organization admin.
6. Create feature flags and enable/disable them.
7. Go to User frontend.
8. Enter organization code and feature key to check whether the feature is enabled.

## API overview

### Auth

- `POST /api/super-admin/login`
- `POST /api/admin/signup`
- `POST /api/admin/login`

### Organizations

- `POST /api/organizations`
- `GET /api/organizations`

### Feature flags

- `POST /api/flags`
- `GET /api/flags`
- `PUT /api/flags/:id`
- `DELETE /api/flags/:id`
- `POST /api/check-feature`

## Design choices

- SQLite was used to keep the assignment simple and easy to run locally.
- Super admin credentials are config-based as mentioned in the problem statement.
- Organization admins are stored in the users table with role `ORG_ADMIN`.
- Feature flags are scoped by `organization_id`, so admins cannot modify flags of other organizations.
- End users do not require login for the demo flow. They check a feature using organization code and feature key.

## Self assessment

- Performance: Suitable for assignment/demo scale. Indexed lookups can be added later for larger usage.
- Readability: Files are separated by database, middleware, routes, and server setup.
- Stability: Common validation and error handling are included.
- Testability: Routes are clearly separated and can be tested using Postman or automated API tests.
