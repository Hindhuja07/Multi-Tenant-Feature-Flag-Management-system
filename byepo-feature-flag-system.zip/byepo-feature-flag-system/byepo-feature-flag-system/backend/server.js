require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const routes = require('./routes');
const { initDatabase } = require('./db');

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// API Routes
app.use('/api', routes);

// Frontend Routes
app.use(
  '/super-admin',
  express.static(path.join(__dirname, '..', 'frontend', 'super-admin'))
);

app.use(
  '/admin',
  express.static(path.join(__dirname, '..', 'frontend', 'admin'))
);

app.use(
  '/user',
  express.static(path.join(__dirname, '..', 'frontend', 'user'))
);

// Home Page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
});

// Initialize Database and Start Server
initDatabase()
  .then(() => {
    app.listen(port, () => {
      console.log(`Feature flag system running at http://localhost:${port}`);
    });
  })
  .catch((err) => {
    console.error('Failed to initialize database', err);
    process.exit(1);
  });