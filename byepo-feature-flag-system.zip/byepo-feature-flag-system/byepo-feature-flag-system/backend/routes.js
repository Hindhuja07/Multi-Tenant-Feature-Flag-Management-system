const express = require('express');
const { all, get, run, makeOrgCode, hashPassword, comparePassword } = require('./db');
const { createToken, authenticate, requireRole } = require('./middleware');

const router = express.Router();

function cleanText(value) {
  return typeof value === 'string' ? value.trim() : '';
}

router.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

router.post('/super-admin/login', async (req, res) => {
  const email = cleanText(req.body.email).toLowerCase();
  const password = cleanText(req.body.password);

  const expectedEmail = (process.env.SUPER_ADMIN_EMAIL || 'superadmin@byepo.local').toLowerCase();
  const expectedPassword = process.env.SUPER_ADMIN_PASSWORD || 'Admin@123';

  if (email !== expectedEmail || password !== expectedPassword) {
    return res.status(401).json({ message: 'Invalid super admin credentials' });
  }

  const token = createToken({ role: 'SUPER_ADMIN', email });
  res.json({ token, user: { email, role: 'SUPER_ADMIN' } });
});

router.post('/organizations', authenticate, requireRole('SUPER_ADMIN'), async (req, res) => {
  try {
    const name = cleanText(req.body.name);
    if (!name) {
      return res.status(400).json({ message: 'Organization name is required' });
    }

    let code = makeOrgCode(name);
    let exists = await get('SELECT id FROM organizations WHERE code = ?', [code]);
    while (exists) {
      code = makeOrgCode(name);
      exists = await get('SELECT id FROM organizations WHERE code = ?', [code]);
    }

    const result = await run('INSERT INTO organizations (name, code) VALUES (?, ?)', [name, code]);
    const organization = await get('SELECT * FROM organizations WHERE id = ?', [result.id]);
    res.status(201).json({ organization });
  } catch (err) {
    if (err.message.includes('UNIQUE')) {
      return res.status(409).json({ message: 'Organization already exists' });
    }
    res.status(500).json({ message: 'Unable to create organization' });
  }
});

router.get('/organizations', authenticate, requireRole('SUPER_ADMIN'), async (req, res) => {
  const organizations = await all(`
    SELECT o.id, o.name, o.code, o.created_at,
      COUNT(DISTINCT u.id) AS admin_count,
      COUNT(DISTINCT f.id) AS flag_count
    FROM organizations o
    LEFT JOIN users u ON u.organization_id = o.id
    LEFT JOIN feature_flags f ON f.organization_id = o.id
    GROUP BY o.id
    ORDER BY o.created_at DESC
  `);
  res.json({ organizations });
});

router.post('/admin/signup', async (req, res) => {
  try {
    const name = cleanText(req.body.name);
    const email = cleanText(req.body.email).toLowerCase();
    const password = cleanText(req.body.password);
    const organizationCode = cleanText(req.body.organizationCode).toUpperCase();

    if (!name || !email || !password || !organizationCode) {
      return res.status(400).json({ message: 'Name, email, password and organization code are required' });
    }

    const organization = await get('SELECT * FROM organizations WHERE code = ?', [organizationCode]);
    if (!organization) {
      return res.status(404).json({ message: 'Organization code not found' });
    }

    const existing = await get('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) {
      return res.status(409).json({ message: 'Email is already registered' });
    }

    const passwordHash = await hashPassword(password);
    const result = await run(
      'INSERT INTO users (name, email, password_hash, role, organization_id) VALUES (?, ?, ?, ?, ?)',
      [name, email, passwordHash, 'ORG_ADMIN', organization.id]
    );

    const token = createToken({ id: result.id, name, email, role: 'ORG_ADMIN', organizationId: organization.id });
    res.status(201).json({
      token,
      user: { id: result.id, name, email, role: 'ORG_ADMIN', organizationId: organization.id, organizationName: organization.name }
    });
  } catch (err) {
    res.status(500).json({ message: 'Unable to complete signup' });
  }
});

router.post('/admin/login', async (req, res) => {
  const email = cleanText(req.body.email).toLowerCase();
  const password = cleanText(req.body.password);

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  const user = await get(`
    SELECT u.*, o.name AS organization_name
    FROM users u
    JOIN organizations o ON o.id = u.organization_id
    WHERE u.email = ? AND u.role = 'ORG_ADMIN'
  `, [email]);

  if (!user || !(await comparePassword(password, user.password_hash))) {
    return res.status(401).json({ message: 'Invalid login details' });
  }

  const token = createToken({ id: user.id, name: user.name, email: user.email, role: user.role, organizationId: user.organization_id });
  res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      organizationId: user.organization_id,
      organizationName: user.organization_name
    }
  });
});

router.get('/flags', authenticate, requireRole('ORG_ADMIN'), async (req, res) => {
  const flags = await all(
    'SELECT id, feature_key, description, is_enabled, created_at, updated_at FROM feature_flags WHERE organization_id = ? ORDER BY created_at DESC',
    [req.user.organizationId]
  );
  res.json({ flags });
});

router.post('/flags', authenticate, requireRole('ORG_ADMIN'), async (req, res) => {
  try {
    const featureKey = cleanText(req.body.featureKey).toLowerCase();
    const description = cleanText(req.body.description);
    const isEnabled = req.body.isEnabled ? 1 : 0;

    if (!featureKey) {
      return res.status(400).json({ message: 'Feature key is required' });
    }

    if (!/^[a-z0-9_\-.]+$/.test(featureKey)) {
      return res.status(400).json({ message: 'Feature key can contain only lowercase letters, numbers, underscore, hyphen and dot' });
    }

    const result = await run(
      'INSERT INTO feature_flags (organization_id, feature_key, description, is_enabled, created_by) VALUES (?, ?, ?, ?, ?)',
      [req.user.organizationId, featureKey, description, isEnabled, req.user.id]
    );
    const flag = await get('SELECT * FROM feature_flags WHERE id = ?', [result.id]);
    res.status(201).json({ flag });
  } catch (err) {
    if (err.message.includes('UNIQUE')) {
      return res.status(409).json({ message: 'Feature key already exists for this organization' });
    }
    res.status(500).json({ message: 'Unable to create feature flag' });
  }
});

router.put('/flags/:id', authenticate, requireRole('ORG_ADMIN'), async (req, res) => {
  const flagId = Number(req.params.id);
  const description = cleanText(req.body.description);
  const isEnabled = req.body.isEnabled ? 1 : 0;

  const result = await run(
    `UPDATE feature_flags
     SET description = ?, is_enabled = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ? AND organization_id = ?`,
    [description, isEnabled, flagId, req.user.organizationId]
  );

  if (!result.changes) {
    return res.status(404).json({ message: 'Feature flag not found' });
  }

  const flag = await get('SELECT * FROM feature_flags WHERE id = ?', [flagId]);
  res.json({ flag });
});

router.delete('/flags/:id', authenticate, requireRole('ORG_ADMIN'), async (req, res) => {
  const flagId = Number(req.params.id);
  const result = await run('DELETE FROM feature_flags WHERE id = ? AND organization_id = ?', [flagId, req.user.organizationId]);

  if (!result.changes) {
    return res.status(404).json({ message: 'Feature flag not found' });
  }

  res.json({ message: 'Feature flag deleted' });
});

router.post('/check-feature', async (req, res) => {
  const organizationCode = cleanText(req.body.organizationCode).toUpperCase();
  const featureKey = cleanText(req.body.featureKey).toLowerCase();

  if (!organizationCode || !featureKey) {
    return res.status(400).json({ message: 'Organization code and feature key are required' });
  }

  const organization = await get('SELECT id, name, code FROM organizations WHERE code = ?', [organizationCode]);
  if (!organization) {
    return res.status(404).json({ message: 'Organization not found' });
  }

  const flag = await get(
    'SELECT feature_key, is_enabled FROM feature_flags WHERE organization_id = ? AND feature_key = ?',
    [organization.id, featureKey]
  );

  res.json({
    organization: organization.name,
    featureKey,
    status: flag && flag.is_enabled ? 'enabled' : 'disabled',
    isEnabled: !!(flag && flag.is_enabled)
  });
});

module.exports = router;
